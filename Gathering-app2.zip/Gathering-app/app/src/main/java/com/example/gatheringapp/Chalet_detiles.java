package com.example.gatheringapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Chalet_detiles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chalet_detiles);




    }
}